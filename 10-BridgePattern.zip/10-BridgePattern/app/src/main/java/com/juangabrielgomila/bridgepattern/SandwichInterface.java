package com.juangabrielgomila.bridgepattern;

/**
 * Created by JuanGabriel on 8/10/17.
 */

public interface SandwichInterface {

    void makeSandwich(String filling1, String filling2);

}
