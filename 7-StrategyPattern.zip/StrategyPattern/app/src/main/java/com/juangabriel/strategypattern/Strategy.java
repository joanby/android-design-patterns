package com.juangabriel.strategypattern;

/**
 * Created by JuanGabriel on 27/9/17.
 */

public interface Strategy {

    String processPayment(float price);

}


