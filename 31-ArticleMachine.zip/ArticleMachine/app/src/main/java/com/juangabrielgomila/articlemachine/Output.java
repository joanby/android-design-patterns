package com.juangabrielgomila.articlemachine;

/**
 * Created by JuanGabriel on 7/12/17.
 */

public class Output {

    private static String output;

    public static String getOutput() {
        return output;
    }

    public static void setOutput(String output) {
        Output.output = output;
    }
}
