package com.juangabrielgomila.decoratorpattern.filling;

/**
 * Created by JuanGabriel on 14/10/17.
 */

public class Ham extends Filling {

    public Ham(){
        description = "Jamón";
        kcal = 83;
    }
}
