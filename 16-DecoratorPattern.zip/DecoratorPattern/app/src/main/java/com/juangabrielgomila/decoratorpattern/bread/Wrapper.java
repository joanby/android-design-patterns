package com.juangabrielgomila.decoratorpattern.bread;

public class Wrapper extends Bread{
    public Wrapper(){
        description = "Pan de pita";
        kcal = 140;
    }
}
