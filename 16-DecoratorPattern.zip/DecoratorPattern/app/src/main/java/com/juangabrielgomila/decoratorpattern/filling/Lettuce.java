package com.juangabrielgomila.decoratorpattern.filling;

/**
 * Created by JuanGabriel on 14/10/17.
 */

public class Lettuce extends Filling {

    public Lettuce(){
        description = "Lechuga";
        kcal = 2;
    }
}
