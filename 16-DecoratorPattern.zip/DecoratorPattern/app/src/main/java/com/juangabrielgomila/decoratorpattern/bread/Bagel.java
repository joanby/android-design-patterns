package com.juangabrielgomila.decoratorpattern.bread;

/**
 * Created by JuanGabriel on 13/10/17.
 */

public class Bagel extends Bread {

    public Bagel(){
        description = "Rosquilla";
        kcal = 280;
    }
}

