package com.juangabrielgomila.decoratorpattern.bread;

public class Baguette extends Bread{
    public Baguette(){
        description = "Barra";
        kcal = 160;
    }
}

